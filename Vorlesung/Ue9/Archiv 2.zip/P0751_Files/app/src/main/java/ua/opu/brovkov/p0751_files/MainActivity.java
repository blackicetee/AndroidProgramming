package ua.opu.brovkov.p0751_files;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;

public class MainActivity extends Activity {
  final String LOG_TAG = "myLogs";
  final String FILENAME = "file";
  final String DIR_SD = "MyFiles";
  final String FILENAME_SD = "fileSD";
  /** Called when the activity is first created. */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
  }

  public void onclick(View v) {
    switch (v.getId()) {
    case R.id.btnWrite:
      writeFile();
      break;
    case R.id.btnRead:
      readFile();
      break;
    case R.id.btnWriteSD:
      writeFileSD();
      break;
    case R.id.btnReadSD:
      readFileSD();
      break;
    }
  }

  void writeFile() {
    try {
      // Open output stream
      BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
          openFileOutput(FILENAME, MODE_PRIVATE)));
      // write data
      bw.write("This is our ");
      bw.write("file content");
      // close stream
      bw.close();
      Log.d(LOG_TAG, "The file is saved");
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  void readFile() {
    try {
      // Open input stream
      BufferedReader br = new BufferedReader(new InputStreamReader(
          openFileInput(FILENAME)));
      String str = "";
      // read data
      while ((str = br.readLine()) != null) {
        Log.d(LOG_TAG, str);
      }
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  void writeFileSD() {
    // Check SD availability
    if (!Environment.getExternalStorageState().equals(
        Environment.MEDIA_MOUNTED)) {
      Log.d(LOG_TAG, "SD-crd is not available: " +
              Environment.getExternalStorageState());
      return;
    }
    // Get a path to SD
    File sdPath = Environment.getExternalStorageDirectory();
    // Add our path
    sdPath = new File(sdPath.getAbsolutePath() + "/" + DIR_SD);
    // create a directory
    sdPath.mkdirs();

    try {
      // create a File object with a file path
      File sdFile = new File(sdPath, FILENAME_SD);
      //Log.d(LOG_TAG, sdFile.toString());
      // Open output stream
      BufferedWriter bw = new BufferedWriter(new FileWriter(sdFile));
      // write data
      bw.write("This is our \n");
      bw.write("file content on our SD!!!");
      // close stream
      bw.close();
      Log.d(LOG_TAG, "File is saved on SD: " + sdFile.getAbsolutePath());
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  void readFileSD() {
    // Check SD availability
    if (!Environment.getExternalStorageState().equals(
        Environment.MEDIA_MOUNTED)) {
      Log.d(LOG_TAG, "SD-crd is not available: " + Environment.getExternalStorageState());
      return;
    }
    // Get a path to SD
    File sdPath = Environment.getExternalStorageDirectory();
    // Add our path
    sdPath = new File(sdPath.getAbsolutePath() + "/" + DIR_SD);
    // create a File object with a file path
    File sdFile = new File(sdPath, FILENAME_SD);
    try {
      // Open input stream
      BufferedReader br = new BufferedReader(new FileReader(sdFile));
      String str = "";
      // Read data
      while ((str = br.readLine()) != null) {
        Log.d(LOG_TAG, str);
      }
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}