package ua.opu.brovkov.p0371_sqliteinnerjoin;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends Activity {

  final String LOG_TAG = "myLogs";

  // Positions
  int[] position_id = { 1, 2, 3, 4 };
  String[] position_name = { "Chef", "Informatiker", "�konom", "Security" };
  int[] position_salary = { 15000, 13000, 10000, 8000 };

  // Persons
  String[] people_name = { "Julian", "Samira", "Elias", "Markus", 
		  				   "Laura", "Alexander", "Daniel", "Lukas" };
  int[] people_posid = { 2, 3, 2, 2, 3, 1, 2, 4 };

  /** Called when the activity is first created. */
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    // Connect to DB
    DBHelper dbh = new DBHelper(this);
    SQLiteDatabase db = dbh.getWritableDatabase();

    Cursor c;

    // Log Table position
    Log.d(LOG_TAG, "--- Table position ---");
    c = db.query("position", null, null, null, null, null, null);
    logCursor(c);
    c.close();
    Log.d(LOG_TAG, "--- ---");

    // Log Table people
    Log.d(LOG_TAG, "--- Table people ---");
    c = db.query("people", null, null, null, null, null, null);
    logCursor(c);
    c.close();
    Log.d(LOG_TAG, "--- ---");

    // Log INNER JOIN with rawQuery
    Log.d(LOG_TAG, "--- INNER JOIN with rawQuery ---");
    String sqlQuery = "select PL.name as Name, "
    	+ "PS.name as Position, salary as Salary "
        + "from people as PL "
        + "inner join position as PS "
        + "on PL.posid = PS.id " 
        //+ "where salary < ? ";
    	+ "where salary > ? or PL.name = ? ";
    //c = db.rawQuery(sqlQuery, new String[] {"12000"});
    c = db.rawQuery(sqlQuery, new String[] {"12000", "Alexander"});

    logCursor(c);
    c.close();
    Log.d(LOG_TAG, "--- ---");

    // Log INNER JOIN with query
    Log.d(LOG_TAG, "--- INNER JOIN with query ---");
    String table = "people as PL inner join position as PS on PL.posid = PS.id";
    String columns[] = { "PL.name as Name", 
    					 "PS.name as Position", 
    					 "salary as Salary" };
    String selection = "salary > ?";
    //String selection = "salary < ? or PL.name = ?";
    String[] selectionArgs = {"12000"};
    //String[] selectionArgs = {"12000", "Lukas"};
    c = db.query(table, columns, selection, selectionArgs, null, null, null);
    logCursor(c);
    c.close();
    Log.d(LOG_TAG, "--- ---");
    
    // Disconnect DB
    dbh.close();
  }

  // Log cursor data
  void logCursor(Cursor c) {
    if (c != null) {
      if (c.moveToFirst()) {
        String str;
        do {
          str = "";
          for (String cn : c.getColumnNames()) {
            str = str.concat(cn + " = " + c.getString(c.getColumnIndex(cn)) + "; ");
          }
          Log.d(LOG_TAG, str);
        } while (c.moveToNext());
      }
    } else
      Log.d(LOG_TAG, "Cursor is null");
  }

  class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
      super(context, "myDB2", null, 1);
    }

    public void onCreate(SQLiteDatabase db) {
      Log.d(LOG_TAG, "--- onCreate database ---");
      ContentValues cv = new ContentValues();
      // Create a table position
      db.execSQL("create table position (" 
          + "id integer primary key,"
          + "name text," + "salary integer" 
          + ");");
      // fill a table position
      for (int i = 0; i < position_id.length; i++) {
        cv.clear();
        cv.put("id", position_id[i]);
        cv.put("name", position_name[i]);
        cv.put("salary", position_salary[i]);
        db.insert("position", null, cv);
      }
      // create a table people
      db.execSQL("create table people ("
          + "id integer primary key autoincrement," 
          + "name text,"
          + "posid integer" 
          + ");");
      // fill a table people
      for (int i = 0; i < people_name.length; i++) {
        cv.clear();
        cv.put("name", people_name[i]);
        cv.put("posid", people_posid[i]);
        db.insert("people", null, cv);
      }
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
  }

}