package ua.opu.brovkov.p0342_simplesqlite_v2;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity implements OnClickListener {
  final String LOG_TAG = "myLogs";
  Button btnAdd, btnRead, btnClear, btnUpd, btnDel;
  EditText etName, etEmail, etID;
  DBHelper dbHelper;
  /** Called when the activity is first created. */
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
    btnAdd = (Button) findViewById(R.id.btnAdd);
    btnAdd.setOnClickListener(this);
    btnRead = (Button) findViewById(R.id.btnRead);
    btnRead.setOnClickListener(this);
    btnClear = (Button) findViewById(R.id.btnClear);
    btnClear.setOnClickListener(this);
    btnUpd = (Button) findViewById(R.id.btnUpd);
    btnUpd.setOnClickListener(this);
    btnDel = (Button) findViewById(R.id.btnDel);
    btnDel.setOnClickListener(this);
    etName = (EditText) findViewById(R.id.etName);
    etEmail = (EditText) findViewById(R.id.etEmail);
    etID = (EditText) findViewById(R.id.etID);
    // an object to create and control a DB 
    dbHelper = new DBHelper(this);
  }
  public void onClick(View v) {
	// an object for data
    ContentValues cv = new ContentValues();
    // get data from user
    String name = etName.getText().toString();
    String email = etEmail.getText().toString();
    String id = etID.getText().toString();
    // connect to DB
    SQLiteDatabase db = dbHelper.getWritableDatabase();
    switch (v.getId()) {
    case R.id.btnAdd:
      Log.d(LOG_TAG, "--- Insert in mytable: ---");
      // prepare a data in a form name - value
      cv.put("name", name);
      cv.put("email", email);
      // insert a record into the table and get the record ID
      long rowID = db.insert("mytable", null, cv);
      Log.d(LOG_TAG, "row inserted, ID = " + rowID);
      break;
    case R.id.btnRead:
      Log.d(LOG_TAG, "--- Rows in mytable: ---");
      // request all data from the table mytable and get Cursor 
      Cursor c = db.query("mytable", null, null, null, null, null, null);
      // set the cursor position on the first element 
      // if no elements are found, we'll get false
      if (c.moveToFirst()) {
        // find the column numbers in the result set using column names
        int idColIndex = c.getColumnIndex("id");
        int nameColIndex = c.getColumnIndex("name");
        int emailColIndex = c.getColumnIndex("email");

        do {
        	// get field values of current record and show all in a log
        	Log.d(LOG_TAG,
              "ID = " + c.getInt(idColIndex) + ", name = "
                  + c.getString(nameColIndex) + ", email = "
                  + c.getString(emailColIndex));
        	// go to the next record; if there are no more records - exit
        } while (c.moveToNext());
      } else
        Log.d(LOG_TAG, "0 rows");
      c.close();
      break;
    case R.id.btnClear:
      Log.d(LOG_TAG, "--- Clear mytable: ---");
      // remove all records
      int clearCount = db.delete("mytable", null, null);
      Log.d(LOG_TAG, "deleted rows count = " + clearCount);
      break;
    case R.id.btnUpd:
      if (id.equalsIgnoreCase("")) {
        break;
      }
      Log.d(LOG_TAG, "--- Update mytabe: ---");
      // prepare values to update
      cv.put("name", name);
      cv.put("email", email);
      // update record with given id
      int updCount = db.update("mytable", cv, "id = ?",
          new String[] { id });
      Log.d(LOG_TAG, "updated rows count = " + updCount);
      break;
    case R.id.btnDel:
      if (id.equalsIgnoreCase("")) {
        break;
      }
      Log.d(LOG_TAG, "--- Delete from mytabe: ---");
      // clear record with given id
      int delCount = db.delete("mytable", "id = " + id, null);
      Log.d(LOG_TAG, "deleted rows count = " + delCount);
      break;
    }
    // close DB connection
    dbHelper.close();
  }
  class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
      super(context, "myDB", null, 1);
    }

    public void onCreate(SQLiteDatabase db) {
      Log.d(LOG_TAG, "--- onCreate database ---");
      // create a table with some columns
      db.execSQL("create table mytable ("
          + "id integer primary key autoincrement," 
          + "name text,"
          + "email text" + ");");
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
  }
}