package ua.opu.brovkov.p1371_sensors;

import java.util.List;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {

	TextView tvText;
	SensorManager sensorManager;
	List<Sensor> sensors;
	Sensor sensorTemperature;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		tvText = (TextView) findViewById(R.id.tvText);
		sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		sensors = sensorManager.getSensorList(Sensor.TYPE_ALL);
		sensorTemperature = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
		//sensorTemperature = sensorManager.getDefaultSensor(Sensor.TYPE_TEMPERATURE);
		//Log.d("myLogs", sensorTemperature.toString());
	}

	public void onClickSensList(View v) {

		sensorManager.unregisterListener(listenerTemperature, sensorTemperature);
		StringBuilder sb = new StringBuilder();

		for (Sensor sensor : sensors) {
			sb.append("name = ").append(sensor.getName()).append(", type = ")
					.append(sensor.getType()).append("\nvendor = ")
					.append(sensor.getVendor()).append(" ,version = ")
					.append(sensor.getVersion()).append("\nmax = ")
					.append(sensor.getMaximumRange()).append(", resolution = ")
					.append(sensor.getResolution())
					.append("\n--------------------------------------\n");
		}
		tvText.setText(sb);
	}

	public void onClickSensLight(View v) {
		sensorManager.registerListener(listenerTemperature, sensorTemperature,
				1000000);//SensorManager.SENSOR_DELAY_NORMAL);
		//SENSOR_DELAY_NORMAL,  SENSOR_DELAY_UI,  SENSOR_DELAY_GAME,  SENSOR_DELAY_FASTEST, us
	}

	@Override
	protected void onPause() {
		super.onPause();
		sensorManager.unregisterListener(listenerTemperature, sensorTemperature);
	}

	SensorEventListener listenerTemperature = new SensorEventListener() {

		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
			Log.d("MyLogs",sensor.toString());
			Log.d("MyLogs","OnAccuracy");
			/*
			SENSOR_STATUS_ACCURACY_HIGH,
			SENSOR_STATUS_ACCURACY_MEDIUM,
			SENSOR_STATUS_ACCURACY_LOW,
			SENSOR_STATUS_UNRELIABLE.
		    */
		}

		@Override
		public void onSensorChanged(SensorEvent event) {
			tvText.setText(String.valueOf(event.values[0]));
		}
	};

}