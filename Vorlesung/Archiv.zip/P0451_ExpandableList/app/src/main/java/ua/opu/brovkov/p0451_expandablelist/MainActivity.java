package ua.opu.brovkov.p0451_expandablelist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ExpandableListView;
import android.widget.SimpleExpandableListAdapter;

public class MainActivity extends Activity {
  // Group names (Company)
  String[] groups = new String[] {"HTC", "Samsung", "LG"};
  // Element names (Phones)
  String[] phonesHTC = new String[] {"HTC One M8s", "HTC One mini 2",
          "HTC Desire 620", "HTC Desire EYE"};
  String[] phonesSams = new String[] {"Galaxy Note5", "Galaxy On7", "Galaxy S6"};
  String[] phonesLG = new String[] {"LG Y70 Spirit", "LG Pada", "LG Leon", "LG Joy"};
  // Group collection
  ArrayList<Map<String, String>> groupData;  
  // Component collection for a single group
  ArrayList<Map<String, String>> childDataItem;
  // common collection for element collections
  ArrayList<ArrayList<Map<String, String>>> childData;
  // result must be: childData = ArrayList<childDataItem>
  // attribute list for a group or an element
  Map<String, String> m;
  ExpandableListView elvMain;
    /** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);       
        // fill a group collection from a group name array
        groupData = new ArrayList<Map<String, String>>();
        for (String group : groups) {
          // fill an attribute list for each group
          m = new HashMap<String, String>();
            m.put("groupName", group); // company name
            groupData.add(m);  
        }        
        // group attribute list for read
        String groupFrom[] = new String[] {"groupName"};
        // ID view-element list for a group attributes
        int groupTo[] = new int[] {android.R.id.text1};
        // a collection of element collections 
        childData = new ArrayList<ArrayList<Map<String, String>>>(); 
        // create a first-group element collection
        childDataItem = new ArrayList<Map<String, String>>();
        // fill an attribute list for each element
        for (String phone : phonesHTC) {
          m = new HashMap<String, String>();
            m.put("phoneName", phone); // phone name
            childDataItem.add(m);  
        }
        // add the collection to the collection of collections
        childData.add(childDataItem);
        // create the second group collection of elements       
        childDataItem = new ArrayList<Map<String, String>>();
        for (String phone : phonesSams) {
          m = new HashMap<String, String>();
            m.put("phoneName", phone);
            childDataItem.add(m);  
        }
        childData.add(childDataItem);
        // create the third group collection of elements        
        childDataItem = new ArrayList<Map<String, String>>();
        for (String phone : phonesLG) {
          m = new HashMap<String, String>();
            m.put("phoneName", phone);
            childDataItem.add(m);  
        }
        childData.add(childDataItem);
        // list of element attributes for read
        String childFrom[] = new String[] {"phoneName"};
        // ID view-element list for a element attributes 
        int childTo[] = new int[] {android.R.id.text1};
        
        SimpleExpandableListAdapter adapter = new SimpleExpandableListAdapter(
            this,
            groupData,
            android.R.layout.simple_expandable_list_item_1,
            groupFrom,
            groupTo,
            childData,
            android.R.layout.simple_list_item_1,
            childFrom,
            childTo);            
        elvMain = (ExpandableListView) findViewById(R.id.elvMain);
        elvMain.setAdapter(adapter);
    }
}