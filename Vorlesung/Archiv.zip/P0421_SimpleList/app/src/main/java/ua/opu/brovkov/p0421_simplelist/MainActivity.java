package ua.opu.brovkov.p0421_simplelist;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {
  String[] names = { "Karl-Heinz", "Linnéa", "Hans-Joachim", 
		  "Anna-Lena", "Lisa-Marie", "Anna-Maria",
          "Elias", "Luca", " Alexander", "Eva-Maria", "Kajetan",
          "Mr. Braun", "Mr. Smith", "Herr Heinig", "Frau Mendelson" };

  /** Called when the activity is first created. */
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
    // Find View
    ListView lvMain = (ListView) findViewById(R.id.lvMain);
    // Create an Adapter
    //ArrayAdapter<String> adapter = 
    //		new ArrayAdapter<String>(this, 
    //				android.R.layout.simple_list_item_1, names);
    ArrayAdapter<String> adapter = 
            new ArrayAdapter<String>(this, R.layout.my_list_item, names);
    // Connect the ListView with the adapter
    lvMain.setAdapter(adapter);
  }
}
